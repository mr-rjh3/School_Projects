"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-10-10"
------------------------------------------------------------------------
"""
from functions import quadrant
x = int(input("Enter the x coordinate: "))
y = int(input("Enter the y coordinate: "))

print()
print(quadrant(x, y))