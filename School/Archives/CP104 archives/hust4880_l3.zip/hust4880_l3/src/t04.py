"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019 M09 23"
------------------------------------------------------------------------
"""

n1 = int(input("First numerator: ")) 
d1 = int(input("First denominator: "))
n2 = int(input("Second numerator: "))
d2 = int(input("Second denominator: "))
r =(n1/d1) * (n2/d2)
print("Product: {:.2f}".format(r))