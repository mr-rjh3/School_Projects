"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-11-12"
------------------------------------------------------------------------
"""

from a8_functions import string_capitalizer
my_str = input('Enter string here: ')
my_str = string_capitalizer(my_str)
print(my_str)