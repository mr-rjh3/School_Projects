"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-11-12"
------------------------------------------------------------------------
"""

from a8_functions import find_frequent

my_str = input("Enter string here: ")
frequent = find_frequent(my_str)
print(frequent)
