"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-11-05"
------------------------------------------------------------------------
"""
from a7_functions import display_pattern

num_lines = int(input("Enter number of lines: "))

display_pattern(num_lines)