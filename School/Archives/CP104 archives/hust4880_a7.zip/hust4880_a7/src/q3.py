"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-11-05"
------------------------------------------------------------------------
"""
from a7_functions import keep_positive_numbers

lst = keep_positive_numbers()

print("List entered: {}".format(lst))
