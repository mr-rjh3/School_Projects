"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updayed__ = "2019-10-2"
------------------------------------------------------------------------
"""
import q3_functions
    
def main():
    
    day_int = int(input("Please enter a number between 1 and 7: "))
    q3_functions.num_day(day_int)
    
    
main()
    