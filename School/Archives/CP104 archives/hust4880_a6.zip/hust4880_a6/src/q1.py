"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-10-22"
------------------------------------------------------------------------
"""
from a6_functions import calc_profit

principal = float(input("Please enter your investment amount: "))
year = int(input("Please enter number of years: "))

calc_profit(principal, year)

