"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2019-10-22"
------------------------------------------------------------------------
"""
from a6_functions import perfect_square

num = int(input("Enter a positive integer: "))

perfect_square(num)