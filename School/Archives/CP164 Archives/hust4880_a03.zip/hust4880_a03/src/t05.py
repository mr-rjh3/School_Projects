"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2020-01-30"
------------------------------------------------------------------------
"""
from functions import is_palindrome_stack

print(is_palindrome_stack('racecar'))
print(is_palindrome_stack('Otto'))
print(is_palindrome_stack('Able was I ere I saw Elba'))
print(is_palindrome_stack('A man, a plan, a canal, Panama!'))