"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2020-01-15"
------------------------------------------------------------------------
"""
from Food import Food
from Food_utilities import get_food, read_food, read_foods, write_foods,\
    food_table, food_search, calories_by_origin, average_calories, by_origin
from utilities import stack_to_array, stack_test, queue_test, priority_queue_test



fv = open('foods.txt', 'r')
foods = read_foods(fv)
fv.close()

#queue_test(foods)

priority_queue_test(foods)
priority_queue_test([])


#print(food_table(foods))
'''
source = [1,2,3,4,5]
stack_test(source)

'''
'''
f = get_food()
print(f)
'''

'''
f = []
f.append(Food('Spanakopita',5,True,260))
f.append(Food('Span',4,False,1100))
f.append(Food('soloa',6,True,260))

food_table(f)

'''


'''
line = 'Spanakopita|5|True|260'
foods = []
food = line.split('|')
print(food)

if(food[2].lower == 'true'):
    food[2] = True
elif(food[2].lower == 'false'):
    food[2] = False
#if(len(food) == 4 and food[2] == True or food[2] == False):
foods.append(Food(food[0], int(food[1]), food[2], int(food[3])))
print(foods)'''