"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2020-01-07"
------------------------------------------------------------------------
"""
from functions import is_valid

print(is_valid('var'))
print(is_valid('var2'))
print(is_valid('2var'))
print(is_valid('var?'))
print(is_valid('camelCase'))