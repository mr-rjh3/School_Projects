"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2020-01-07"
------------------------------------------------------------------------
"""

from functions import max_diff

print(max_diff([]))
print(max_diff([0, 0, 0, 0]))
print(max_diff([0, 1, 2, 3]))
print(max_diff([5, 10, 20, 40]))
print(max_diff([-5, 5, 7, 11]))