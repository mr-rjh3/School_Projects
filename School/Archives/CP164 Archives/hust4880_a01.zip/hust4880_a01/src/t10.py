"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2020-01-16"
------------------------------------------------------------------------
"""
from functions import pig_latin

print(pig_latin("ASAASASASASA"))