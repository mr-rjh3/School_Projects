"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Riley Huston
ID:     190954880
Email:  hust4880@mylaurier.ca
__updated__ = "2020-04-01"
------------------------------------------------------------------------
"""
from test_Sorts_array import test_sort
from Sorts_array import Sorts

test_sort('Bubble sort', Sorts.bubble_sort)